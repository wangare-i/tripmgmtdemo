/**
 * Spring Security configuration.
 */
package com.example.travel.security;
