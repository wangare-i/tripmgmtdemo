/**
 * JPA domain objects.
 */
package com.example.travel.domain;
