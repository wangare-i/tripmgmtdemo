/**
 * Service layer beans.
 */
package com.example.travel.service;
