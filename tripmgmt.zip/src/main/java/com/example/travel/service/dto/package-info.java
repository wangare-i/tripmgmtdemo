/**
 * Data Transfer Objects.
 */
package com.example.travel.service.dto;
