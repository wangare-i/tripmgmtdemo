/**
 * Spring Data JPA repositories.
 */
package com.example.travel.repository;
