/**
 * View Models used by Spring MVC REST controllers.
 */
package com.example.travel.web.rest.vm;
